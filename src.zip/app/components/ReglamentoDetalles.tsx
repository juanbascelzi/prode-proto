import React from 'react';

function Title1() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Títle">
      <p className="font-['Roboto:SemiBold','Noto_Sans_Symbols:SemiBold',sans-serif] font-semibold leading-[1.4] relative shrink-0 text-[#303036] text-[18px] tracking-[0.036px] w-full whitespace-pre-wrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        🏆 Reglas de puntaje → Prode Humand
      </p>
    </div>
  );
}

function Title2() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full whitespace-pre-wrap" data-name="Títle">
      <p className="font-['Roboto:SemiBold',sans-serif] font-semibold leading-[1.4] relative shrink-0 text-[#303036] text-[16px] tracking-[0.032px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        1. Qué resultado se toma
      </p>
      <ul className="block font-['Roboto:Regular',sans-serif] font-normal leading-normal list-disc relative shrink-0 text-[#636271] text-[14px] tracking-[0.028px] w-full pl-5 mt-1" style={{ fontVariationSettings: "'wdth' 100" }}>
        <li className="mb-0">
          <span className="leading-[1.4]">Se toma el resultado del </span>
          <span className="font-semibold leading-[1.4] tracking-[0.028px]">partido completo: 90’ + alargue</span>
          <span className="leading-[1.4]"> si hay.</span>
        </li>
        <li className="mb-0">
          <span className="font-semibold leading-[1.4] tracking-[0.028px]">
            Penales no cuentan
          </span>
          <span className="leading-[1.4]"> para el marcador.</span>
        </li>
        <li>
          <span className="leading-[1.4]">En </span>
          <span className="font-semibold leading-[1.4] tracking-[0.028px]">
            eliminación directa,
          </span>
          <span className="leading-[1.4]"> si hay penales, sí cuenta </span>
          <span className="font-semibold leading-[1.4] tracking-[0.028px]">
            quién clasifica.
          </span>
        </li>
      </ul>
    </div>
  );
}

function Divider() {
  return (
    <div className="h-px relative shrink-0 w-full my-4" data-name="Divider">
      <div aria-hidden="true" className="absolute border-b border-[#eeeef1] inset-0 pointer-events-none" />
    </div>
  );
}

function Title3() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Títle">
      <p className="font-['Roboto:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#636271] text-[14px] tracking-[0.028px] w-full whitespace-pre-wrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <span className="leading-[1.4]">En cada partido </span>
        <span className="font-semibold leading-[1.4]" style={{ fontVariationSettings: "'wdth' 100" }}>
          solo ganas el mayor puntaje que corresponda
        </span>
        <span className="leading-[1.4]"> (no se suman entre sí)</span>
      </p>
    </div>
  );
}

function Title4() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Títle">
      <p className="font-['Roboto:SemiBold',sans-serif] font-semibold leading-[1.4] relative shrink-0 text-[#303036] text-[16px] tracking-[0.032px] w-full whitespace-pre-wrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        A) Si aciertas el marcador exacto
      </p>
      <ul className="block font-['Roboto:Regular','Noto_Sans_Symbols:SemiBold',sans-serif] font-normal leading-normal relative shrink-0 text-[#636271] text-[14px] tracking-[0.028px] w-full pl-5 mt-1" style={{ fontVariationSettings: "'wdth' 100" }}>
        <li className="list-disc whitespace-pre-wrap">
          <span className="font-semibold leading-[1.4] tracking-[0.028px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            12 puntos →
          </span>
          <span className="leading-[1.4]"> aciertas el resultado y los goles de ambos equipos</span>
        </li>
      </ul>
    </div>
  );
}

function Title5() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full whitespace-pre-wrap" data-name="Títle">
      <p className="font-['Roboto:SemiBold',sans-serif] font-semibold leading-[1.4] relative shrink-0 text-[#303036] text-[16px] tracking-[0.032px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        B) Si no aciertas el marcador exacto, pero estuviste cerca
      </p>
      <div className="flex flex-col gap-1 mt-1">
        <p className="font-['Roboto:Regular',sans-serif] font-normal text-[#636271] text-[14px] leading-[1.4]">
          <span className="font-semibold text-[#636271]">8 puntos </span>
          si:
        </p>
        <ul className="list-disc pl-5 flex flex-col gap-1">
          <li className="font-['Roboto:Regular',sans-serif] font-normal text-[#636271] text-[14px] leading-[1.4]">
            <span>El partido terminó en </span>
            <span className="font-semibold">empate</span>
            <span> y tu también pronosticaste </span>
            <span className="font-semibold text-[#636271]">empate </span>
            <span>(aunque no sean los mismos goles), </span>
            <span className="font-semibold">o</span>
          </li>
          <li className="font-['Roboto:Regular',sans-serif] font-normal text-[#636271] text-[14px] leading-[1.4]">
            <span>Acertaste el </span>
            <span className="font-semibold">ganador</span>
            <span> y también la </span>
            <span className="font-semibold">diferencia de goles</span>
            <span> (ej: real 3-1 y tu has puesto 2-0, ambos diferencia +2)</span>
          </li>
        </ul>
      </div>
    </div>
  );
}

function Title6() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Títle">
      <p className="font-['Roboto:SemiBold',sans-serif] font-semibold leading-[1.4] relative shrink-0 text-[#303036] text-[16px] tracking-[0.032px] w-full whitespace-pre-wrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        C) Si aciertas solo el resultado (ganador)
      </p>
      <ul className="block font-['Roboto:SemiBold','Noto_Sans_Symbols:SemiBold','Noto_Sans_Symbols:Regular',sans-serif] leading-normal relative shrink-0 text-[#636271] text-[14px] tracking-[0.028px] w-full pl-5 mt-1" style={{ fontVariationSettings: "'wdth' 100" }}>
        <li className="list-disc mb-0 whitespace-pre-wrap">
          <span className="font-semibold leading-[1.4]">2 puntos → </span>
          <span className="font-normal leading-[1.4] tracking-[0.028px]">aciertas exactamente los goles de </span>
          <span className="font-semibold leading-[1.4]">uno</span>
          <span className="font-normal leading-[1.4] tracking-[0.028px]"> de los dos equipos (A o B), aunque el resultado te haya dado mal.</span>
        </li>
      </ul>
      <p className="font-normal leading-[1.4] text-[#636271] text-[14px] tracking-[0.028px] mt-1 pl-5">
        Ej: real 3-1, pronóstico 3-0 → suma 2.
      </p>
    </div>
  );
}

function Title7() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Títle">
      <p className="font-['Roboto:SemiBold',sans-serif] font-semibold leading-[1.4] relative shrink-0 text-[#303036] text-[16px] tracking-[0.032px] w-full whitespace-pre-wrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        D) Si no aciertas a nada
      </p>
      <ul className="block leading-normal relative shrink-0 text-[#636271] text-[14px] tracking-[0.028px] w-full pl-5 mt-1" style={{ fontVariationSettings: "'wdth' 100" }}>
        <li className="list-disc whitespace-pre-wrap">
          <span className="leading-[1.4]">0 puntos</span>
        </li>
      </ul>
    </div>
  );
}

export function ReglamentoDetallesView() {
  return (
    <div className="flex flex-col gap-4 w-full pb-10">
      <div className="content-stretch flex flex-col items-start relative shrink-0 w-full mb-2" data-name="Títle">
        <p className="font-['Roboto:SemiBold',sans-serif] font-semibold leading-[1.4] relative shrink-0 text-[#303036] text-[16px] tracking-[0.032px] w-full whitespace-pre-wrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          Sistema de puntaje
        </p>
      </div>

      <div className="bg-white border border-[#eeeef1] rounded-[16px] p-[24px] flex flex-col gap-[16px] relative w-full">
        <Title1 />
        <Title2 />
        <Divider />
        <p className="font-semibold leading-[1.4] relative shrink-0 text-[#303036] text-[18px] tracking-[0.036px] w-full whitespace-pre-wrap">
          ⚽ Puntaje por partido
        </p>
        <Title3 />
        <Title4 />
        <Title5 />
        <Title6 />
        <Title7 />
        
        <Divider />
        
        <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Títle">
          <p className="font-semibold leading-[1.4] relative shrink-0 text-[#303036] text-[18px] tracking-[0.036px] w-full whitespace-pre-wrap">
            🥅 Bonus en eliminación directa: “Quién clasifica”
          </p>
        </div>
        
        <div className="font-['Roboto:Regular',sans-serif] font-normal leading-normal relative shrink-0 text-[#636271] text-[14px] tracking-[0.028px] w-full whitespace-pre-wrap">
          <p className="font-semibold leading-[1.4] mb-2">
            Si el partido se define por penales:
          </p>
          <ul className="list-disc pl-5 flex flex-col gap-2">
            <li>
              <span className="font-semibold leading-[1.4] tracking-[0.028px]">
                + 3 puntos
              </span>
              <span className="leading-[1.4]"> si aciertas </span>
              <span className="font-semibold leading-[1.4] tracking-[0.028px]">
                quién clasifica
              </span>
              <span className="leading-[1.4]"> a la siguiente ronda</span>
            </li>
            <li>
              <span className="leading-[1.4]">Este bonus </span>
              <span className="font-semibold leading-[1.4] tracking-[0.028px]">
                se suma
              </span>
              <span className="leading-[1.4]"> a los puntos del partido.</span>
            </li>
          </ul>
        </div>

        <Divider />
        
        <p className="font-semibold leading-[1.4] relative shrink-0 text-[#303036] text-[18px] tracking-[0.036px] w-full whitespace-pre-wrap">
          🥇 Pronósticos especiales – Podio del torneo
        </p>
        <div className="font-normal leading-normal relative shrink-0 text-[#636271] text-[14px] tracking-[0.028px] w-full whitespace-pre-wrap">
          <p className="font-semibold mb-2">
            <span className="leading-[1.4]">Se eligen antes de empezar el torneo </span>
            <span className="font-normal leading-[1.4] tracking-[0.028px]">
              y suman a la tabla general:
            </span>
          </p>
          <ul className="list-disc pl-5 flex flex-col gap-1">
            <li>
              <span className="leading-[1.4]">🥇 Campeón: </span>
              <span className="font-normal leading-[1.4] tracking-[0.028px]">
                20 pts
              </span>
            </li>
            <li>
              <span className="leading-[1.4]">🥈 Subcampeón:</span>
              <span className="font-normal leading-[1.4] tracking-[0.028px]"> 10 pts</span>
            </li>
            <li>
              <span className="leading-[1.4]">🥉 Tercer puesto</span>
              <span className="font-normal leading-[1.4] tracking-[0.028px]">
                : 6 pts
              </span>
            </li>
          </ul>
        </div>

        <Divider />
        
        <p className="font-semibold leading-[1.4] relative shrink-0 text-[#303036] text-[18px] tracking-[0.036px] w-full whitespace-pre-wrap">
          🔥 Reglas de desempate del ranking (en orden)
        </p>
        <div className="font-normal leading-normal relative shrink-0 text-[#636271] text-[14px] tracking-[0.028px] w-full">
          <p className="mb-4 text-[14px] whitespace-pre-wrap">
            <span className="leading-[1.4]">Si dos o más usuarios quedan con </span>
            <span className="font-semibold leading-[1.4] tracking-[0.028px]">
              el mismo puntaje total,
            </span>
            <span className="leading-[1.4]">
              {" se desempata así:"}
            </span>
          </p>
          <ol className="list-decimal pl-5 flex flex-col gap-4">
            <li className="whitespace-pre-wrap">
              <span className="font-semibold leading-[1.4] text-[14px] tracking-[0.028px]">
                Más partidos con 12 puntos (marcador exacto)
              </span>
              <ul className="list-disc pl-5 mt-1">
                <li className="whitespace-pre-wrap">
                  <span className="leading-[1.4] text-[14px]">Premia máxima precisión.</span>
                </li>
              </ul>
            </li>
            <li className="whitespace-pre-wrap">
              <span className="font-semibold leading-[1.4] text-[14px] tracking-[0.028px]">
                Más partidos con 8 puntos (cercanos: empate o diferencia correcta)
              </span>
              <ul className="list-disc pl-5 mt-1">
                <li className="whitespace-pre-wrap">
                  <span className="leading-[1.4] text-[14px]">Premia el “casi exacto” de forma consistente con el sistema.</span>
                </li>
              </ul>
            </li>
            <li className="whitespace-pre-wrap">
              <span className="font-semibold leading-[1.4] text-[14px] tracking-[0.028px]">
                Más aciertos de “Quién clasifica” (+3) en eliminación directa
              </span>
              <ul className="list-disc pl-5 mt-1">
                <li className="whitespace-pre-wrap">
                  <span className="leading-[1.4] text-[14px]">Premia lectura táctica de playoffs.</span>
                </li>
              </ul>
            </li>
            <li className="whitespace-pre-wrap">
              <span className="font-semibold leading-[1.4] text-[14px] tracking-[0.028px]">
                Más aciertos parciales de 2 puntos (goles de un equipo)
              </span>
              <ul className="list-disc pl-5 mt-1">
                <li className="whitespace-pre-wrap">
                  <span className="leading-[1.4] text-[14px]">Premia consistencia precisa aunque no siempre acierte resultado</span>
                </li>
              </ul>
            </li>
            <li className="text-[14px] whitespace-pre-wrap">
              <span className="font-semibold leading-[1.4] tracking-[0.028px]">Timestamp del primer pronóstico hecho (más temprano gana) ✅ </span>
              <span className="leading-[1.4]">(desempate garantizado 100%)</span>
              <ul className="list-disc pl-5 mt-1 whitespace-pre-wrap">
                <li className="text-[14px]">
                  <span className="leading-[1.4]">Si quieres que premie 'compromiso', este criterio es ideal</span>
                </li>
              </ul>
            </li>
          </ol>
        </div>
      </div>
    </div>
  );
}
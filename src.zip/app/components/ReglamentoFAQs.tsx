import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

function Accordion({ 
  question, 
  answer, 
  isOpen, 
  onToggle 
}: { 
  question: string, 
  answer: string, 
  isOpen: boolean, 
  onToggle: () => void 
}) {
  return (
    <div className="w-full bg-white rounded-[8px] border border-[#eeeef1] overflow-hidden transition-all duration-200">
      <button 
        onClick={onToggle}
        className="w-full flex items-center justify-between p-[16px] text-left gap-4 active:bg-gray-50 transition-colors"
      >
        <span className="font-semibold text-[16px] text-[#303036] leading-[1.4]">{question}</span>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.2 }}
        >
          <ChevronDown className="w-5 h-5 text-[#303036]" />
        </motion.div>
      </button>
      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.04, 0.62, 0.23, 0.98] }}
          >
            <div className="px-[16px] pb-[16px] text-[14px] text-[#636271] leading-[1.6] border-t border-[#f8f8fa] pt-4">
              {answer}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function ReglamentoFAQsView() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      question: "¿Qué es el módulo de Pronósticos Deportivos?",
      answer: "Es un módulo de Humand que permite a las comunidades crear competencias de pronósticos deportivos, donde los participantes suman puntos y compiten en un ranking."
    },
    {
      question: "¿Qué es una competencia?",
      answer: "Es una instancia dentro del módulo en la que un grupo de usuarios participa prediciendo partidos y acumulando puntos según sus aciertos."
    },
    {
      question: "¿Puedo participar en más de una competencia?",
      answer: "Sí. Puedes participar en múltiples competencias al mismo tiempo. Cada una funciona de manera independiente y los pronósticos se realizan por competencia, incluso si el partido es el mismo."
    },
    {
      question: "¿Qué puedo pronosticar en cada partido?",
      answer: "El marcador final del partido considerando los 90 minutos reglamentarios más el tiempo adicional, en caso de haber. En caso de empate, se puede pronosticar qué equipo clasifica. No se considera el marcador exacto de penales."
    },
    {
      question: "¿Hasta cuándo puedo cargar o modificar un pronóstico?",
      answer: "Hasta 1 minuto antes del inicio del partido. Una vez iniciado, el pronóstico queda bloqueado y no puede modificarse."
    },
    {
      question: "¿Puedo ver los pronósticos de otros participantes?",
      answer: "No. Los pronósticos de otros participantes no son visibles para el resto."
    },
    {
      question: "¿Cómo se calculan y cuándo se asignan los puntos?",
      answer: "Los puntos se asignan según el nivel de acierto del pronóstico. Para más detalle, consulta la sección Sistema de Puntajes. Una vez finalizado el partido y cargado el resultado, el sistema asigna los puntos automáticamente."
    },
    {
      question: "¿Qué son las predicciones especiales y otorgan puntos?",
      answer: "Son pronósticos adicionales definidos por la competencia, como campeón, subcampeón y tercer puesto. El usuario obtiene puntos adicionales si acierta estas predicciones."
    },
    {
      question: "¿Cuándo debo hacer las predicciones especiales?",
      answer: "Antes de que comience la competencia. Una vez iniciada, no se pueden modificar. Si no se realizan, no se asignan puntos adicionales."
    },
    {
      question: "¿Cómo funciona el ranking?",
      answer: "El ranking se ordena según la cantidad total de puntos acumulados dentro de la competencia."
    },
    {
      question: "¿Qué pasa si hay empate en el ranking?",
      answer: "El sistema puede aplicar criterios de desempate definidos específicamente para la competencia."
    },
    {
      question: "¿Quién crea y administra una competencia y define sus reglas y premios?",
      answer: "Los administradores de la comunidad crean y administran la competencia, y definen sus reglas y premios."
    },
    {
      question: "¿Humand gestiona o garantiza premios?",
      answer: "No, Humand provee el módulo, pero la gestión y entrega de premios es responsabilidad del organizador."
    },
    {
      question: "¿Los horarios de los partidos están ajustados a mi zona horaria?",
      answer: "Sí. Los partidos se muestran automáticamente según tu zona horaria."
    }
  ];

  const handleToggle = (index: number) => {
    setOpenIndex(prevIndex => prevIndex === index ? null : index);
  };

  return (
    <div className="flex flex-col gap-[16px] w-full pb-10">
      <div className="flex flex-col gap-[16px]">
        {faqs.map((faq, index) => (
          <Accordion 
            key={index}
            question={faq.question} 
            answer={faq.answer} 
            isOpen={openIndex === index}
            onToggle={() => handleToggle(index)}
          />
        ))}
      </div>
    </div>
  );
}